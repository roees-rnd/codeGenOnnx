//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: model31_func_data.cpp
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 27-Jul-2021 10:34:40
//

// Include Files
#include "model31_func_data.h"

// Variable Definitions
omp_nest_lock_t emlrtNestLockGlobal;

boolean_T isInitialized_model31_func{false};

//
// File trailer for model31_func_data.cpp
//
// [EOF]
//
