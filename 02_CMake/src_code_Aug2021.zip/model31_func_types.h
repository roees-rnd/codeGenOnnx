//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: model31_func_types.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 27-Jul-2021 10:34:40
//

#ifndef MODEL31_FUNC_TYPES_H
#define MODEL31_FUNC_TYPES_H

// Include Files
#include "rtwtypes.h"
#define MAX_THREADS omp_get_max_threads()

#endif
//
// File trailer for model31_func_types.h
//
// [EOF]
//
