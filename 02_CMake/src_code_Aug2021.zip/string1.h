//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: string1.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 27-Jul-2021 10:34:40
//

#ifndef STRING1_H
#define STRING1_H

// Include Files
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Type Definitions
namespace coder {
class rtString {
};

} // namespace coder

#endif
//
// File trailer for string1.h
//
// [EOF]
//
