//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: model31_func_internal_types.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 27-Jul-2021 10:34:40
//

#ifndef MODEL31_FUNC_INTERNAL_TYPES_H
#define MODEL31_FUNC_INTERNAL_TYPES_H

// Include Files
#include "model31_func_types.h"
#include "rtwtypes.h"
#include "string1.h"

// Type Definitions
namespace coder {
namespace ctarget {
struct coder_ctarget_DeepLearningNetwork_tag_0 {
  rtString State;
  boolean_T IsInitialized;
};
typedef coder_ctarget_DeepLearningNetwork_tag_0 DeepLearningNetwork;

} // namespace ctarget
} // namespace coder

#endif
//
// File trailer for model31_func_internal_types.h
//
// [EOF]
//
