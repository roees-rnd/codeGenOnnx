//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: model31_func_initialize.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 27-Jul-2021 10:34:40
//

#ifndef MODEL31_FUNC_INITIALIZE_H
#define MODEL31_FUNC_INITIALIZE_H

// Include Files
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void model31_func_initialize();

#endif
//
// File trailer for model31_func_initialize.h
//
// [EOF]
//
