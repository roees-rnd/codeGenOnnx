//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: model31_func_data.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 27-Jul-2021 10:34:40
//

#ifndef MODEL31_FUNC_DATA_H
#define MODEL31_FUNC_DATA_H

// Include Files
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Variable Declarations
extern omp_nest_lock_t emlrtNestLockGlobal;
extern boolean_T isInitialized_model31_func;

#endif
//
// File trailer for model31_func_data.h
//
// [EOF]
//
